package controllers;

public class Result {
    private boolean success;
    private String message;
    public Result(boolean s, String m) { success = s; message = m; }
    public boolean isSuccess() { return success; }
    public String getMessage() { return message; }
}
