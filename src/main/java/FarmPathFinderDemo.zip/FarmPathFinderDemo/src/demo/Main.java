package demo;

import controllers.PathFinder;
import controllers.Result;
import models.*;
import models.enums.TileType;
import java.util.List;

public class Main {
    static final int SIZE=15;
    static final String[] mapData = {
        "H.W.LL..W.L.T..",
        ".W.L.W..LL.W.LS",
        ".W.W.LL.W..L.S.",
        "...W....W.LL.L.",
        ".LLLLL.W...L...",
        "...W...LL.W.LL.",
        ".LL.LL...W.....",
        ".W...LLL.LLL...",
        ".W.LL.W......W.",
        "...LL...LL.W...",
        "LL..LLL..W.L.LL",
        ".W...W....W..F.",
        ".W.LLL.WWWW..W.",
        ".W.....W.....W.",
        "...LLLLL.LL...."
    };

    public static void main(String[] args) {
        // build farm
        Farm farm=new Farm(SIZE,SIZE);
        Position start=null, finish=null;
        for(int y=0;y<SIZE;y++){
            for(int x=0;x<SIZE;x++){
                char c=mapData[y].charAt(x);
                Tile t=new Tile(null,new Position(x,y));
                switch(c){
                    case 'H': start=new Position(x,y); t.setType(TileType.GRASS); break;
                    case 'F': finish=new Position(x,y); t.setType(TileType.GRASS); break;
                    case 'W': t.setType(TileType.WATER); break;
                    case 'S': t.setType(TileType.STONE); break;
                    case 'T': t.setType(TileType.TREE); break;
                    case 'L': t.setType(TileType.WOOD_LOG); break;
                    case 'g': t.setType(TileType.GREENHOUSE); break;
                    case 'c': t.setType(TileType.CABIN); break;
                    case 'q': t.setType(TileType.QUARRY); break;
                    case 'a': t.setType(TileType.ANIMAL); break;
                    case 'P': t.setType(TileType.PLOWED_SOIL); break;
                    case 'N': t.setType(TileType.NOT_PLOWED_SOIL); break;
                    case 's': t.setType(TileType.PLANTED_SEED); break;
                    case 'r': t.setType(TileType.GROWING_CROP); break;
                    default:  t.setType(TileType.GRASS);
                }
                farm.addTile(t);
            }
        }

        User user=new User(farm,start,1000);
        PathFinder pf=new PathFinder(user);
        Result res=pf.respondForWalkRequest(
            Integer.toString(finish.getX()),
            Integer.toString(finish.getY())
        );
        System.out.println(res.getMessage()); if(!res.isSuccess()) return;

        Path path=pf.findValidPath(start,finish);
        System.out.println(pf.walk(path,"y").getMessage());

        // display with path
        char[][] disp=new char[SIZE][SIZE];
        for(int y=0;y<SIZE;y++) disp[y]=mapData[y].toCharArray();
        for(Tile t: path.getPathTiles()){
            int x=t.getPosition().getX(), y=t.getPosition().getY();
            if(!(x==start.getX()&&y==start.getY())
               &&!(x==finish.getX()&&y==finish.getY()))
                disp[y][x]='.';
        }
        System.out.println("\nMap with path marked as '.':");
        for(char[] r:disp) System.out.println(new String(r));
    }
}
