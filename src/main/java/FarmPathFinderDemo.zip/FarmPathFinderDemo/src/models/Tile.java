package models;

import models.enums.TileType;

public class Tile {
    private TileType type;
    private Position position;
    private Object itemPlaced;

    public Tile(TileType type, Position pos) {
        this.type = type;
        this.position = pos;
    }

    public TileType getType() { return type; }
    public void setType(TileType type) { this.type = type; }
    public Position getPosition() { return position; }
    public Object getItemPlaced() { return itemPlaced; }
    public void placeItem(Object item) {
        this.itemPlaced = item;
        this.type = TileType.UNDER_AN_ITEM;
    }
}
