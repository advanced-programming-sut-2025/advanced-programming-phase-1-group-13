package models;

import models.enums.TileType;
import java.util.*;

public class Farm {
    private int width, height;
    private List<Tile> farmTiles;

    public Farm(int width, int height) {
        this.width = width;
        this.height = height;
        this.farmTiles = new ArrayList<>();
    }

    public void addTile(Tile t) { farmTiles.add(t); }
    public Tile getTileAt(int x, int y) {
        for (Tile t: farmTiles) {
            if (t.getPosition().getX()==x && t.getPosition().getY()==y) return t;
        }
        return null;
    }
    public int getWidth() { return width; }
    public int getHeight() { return height; }
    public List<Tile> getFarmTiles() { return farmTiles; }
}
