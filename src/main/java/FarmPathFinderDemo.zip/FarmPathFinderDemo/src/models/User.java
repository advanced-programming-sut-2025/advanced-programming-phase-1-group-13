package models;

public class User {
    private Farm farm;
    private Position position;
    private int energy;

    public User(Farm farm, Position start, int energy) {
        this.farm = farm;
        this.position = start;
        this.energy = energy;
    }
    public Farm getFarm() { return farm; }
    public Position getPosition() { return position; }
    public void changePosition(Position p) { this.position = p; }
    public int getEnergy() { return energy; }
    public void setEnergy(int e) { this.energy = e; }
}
