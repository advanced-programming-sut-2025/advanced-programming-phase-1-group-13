package com.ap_project.models.inventory;

public class Refrigerator extends Inventory {
    public Refrigerator() {
        super(Integer.MAX_VALUE, true);
    }
}
