package com.project.models.enums.types;

public interface ItemType {
    public String getName();
}
