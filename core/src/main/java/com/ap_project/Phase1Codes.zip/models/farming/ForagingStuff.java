package com.ap_project.models.farming;

public interface ForagingStuff {
    public void generate();
}
