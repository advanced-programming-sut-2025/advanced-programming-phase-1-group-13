package com.project.models;

import java.util.ArrayList;

public class Lake {
    private ArrayList<Position> tiles;

    public ArrayList<Position> getTiles() {
        return tiles;
    }

    public void setTiles(ArrayList<Position> tiles) {
        this.tiles = tiles;
    }
}
