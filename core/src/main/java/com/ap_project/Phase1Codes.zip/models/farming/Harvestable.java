package com.project.models.farming;

public interface Harvestable {
    public void showInfo();
}
