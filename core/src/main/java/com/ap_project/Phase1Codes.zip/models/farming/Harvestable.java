package com.ap_project.models.farming;

public interface Harvestable {
    public void showInfo();
}
