package com.ap_project.models.enums.types;

public enum Role {
    SHOPKEEPER,
    VILLAGER;
}
