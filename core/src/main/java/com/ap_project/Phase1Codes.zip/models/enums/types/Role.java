package com.project.models.enums.types;

public enum Role {
    SHOPKEEPER,
    VILLAGER;
}
