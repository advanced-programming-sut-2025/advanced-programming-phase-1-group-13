package com.project.views;

import java.util.Scanner;

public class AvatarMenu implements AppMenu {

    @Override
    public void check(Scanner scanner) {

    }
}
