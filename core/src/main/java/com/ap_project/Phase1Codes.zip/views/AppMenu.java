package com.project.views;

import java.util.Scanner;

public interface AppMenu {
    public abstract void check(Scanner scanner);
}
