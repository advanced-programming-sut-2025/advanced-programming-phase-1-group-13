package controller.player;

import model.Result;

public class GameController {
    public Result walk() {

    }

    private Path foundValidPath(Position origin, Position destination) {
        if (!isDestinationAllowed(destination)) {
            return null;
        }
        // TODO
    }

    private boolean isDestinationAllowed(Position destination) {
        // TODO
    }

}
