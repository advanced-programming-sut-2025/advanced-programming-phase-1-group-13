package controller.user;

import model.Result;

public class ProfileController {
    public Result changeUsername(String newUsername) {

    }

    public Result changeNickname(String newNickname) {

    }

    public Result changeEmail(String newEmail) {

    }

    public Result changePassword(String oldPassword, String newPassword){

    }


}
