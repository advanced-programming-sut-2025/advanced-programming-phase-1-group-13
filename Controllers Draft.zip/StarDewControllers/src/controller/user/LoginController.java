package controller.user;

import model.Result;
import model.User;

public class LoginController {
    public static User getUserByUsername(String username) {

    }

    public Result login(String username, String password) {

    }

    public Result askSecurityQuestion() {

    }

    public Result validateSecurityQuestion(User user, String answerToSecurityQuestion) {

    }

    public Result forgotPassword(String username, String email) {

    }

}
