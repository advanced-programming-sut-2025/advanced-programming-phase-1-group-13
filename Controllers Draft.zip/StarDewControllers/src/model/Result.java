package model;

public class Result {
}
